# SkillBridge AI 🌉
### Bridging the Gap Between Education and Employment

SkillBridge AI is a student-centric platform designed to solve the "Competency Calibrated" problem. It uses AI to analyze a student's current profile, identify gaps, and generate hyper-personalized roadmaps to get them market-ready.

## 🚀 Key Features

### 1. Guided Discovery & Skill Matching
- **Honest Review System:** Replaces generic advice with hard-hitting, data-backed reality checks.
- **AI Roadmapping:** Generates a week-by-week plan with specific, high-quality resources (Striver, CodeWithHarry, etc.).
- **Readiness Score:** A quantifiable metric (0-100) showing how close you are to being hireable.

### 2. Resume Scrutiny ("Ready Check")
- **PDF Upload & Parsing:** Upload your actual resume (PDF).
- **ATS Analysis:** The AI simulates an Applicant Tracking System to find missing keywords.
- **Actionable Feedback:** Tells you exactly what to fix (formatting, metrics, keywords).

### 3. Student Job Board
- **Direct Connect:** Apply directly to recruiters who are looking for pre-vetted talent.
- **Verified Listings:** No ghosting, no fake jobs.

## 🛠️ Tech Stack
- **Frontend:** Vanilla HTML5, CSS3 (Glassmorphism Design), JavaScript (ES6+).
- **AI/Backend Simulation:** Custom `mockService.js` simulating API delays and AI responses.
- **PDF Parsing:** `pdf.js` for client-side resume analysis.
- **Icons:** FontAwesome 6.
- **Fonts:** 'Outfit' and 'Space Grotesk' from Google Fonts.

## 📦 How to Run Locally
1. Clone this repository (or unzip the folder).
2. Open `index.html` in any modern web browser.
3. **Important:** For the PDF parsing to work correctly, you might need to run it on a local server (due to CORS policies in some browsers), but it generally works fine for local files in Chrome/Edge.
   - *Recommendation:* Use VS Code's "Live Server" extension.

## 🔮 Future Roadmap
- [ ] Integration with LinkedIn API for auto-profile import.
- [ ] "Mock Interview" bot using Speech-to-Text.
- [ ] Gamification (XP, streaks) for completing roadmap items.

---
*Built with ❤️ for the Hackathon 2026*
